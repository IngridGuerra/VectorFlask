# VectorFlask
VSM using Flask as server

PS. Still missing to create a Virtual Environment in VSCode to run the app
https://code.visualstudio.com/docs/python/tutorial-flask

Command to run Flask app: python3 -m flask run
*Quit 3 if Windows

